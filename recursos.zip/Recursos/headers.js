/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//document.write('<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />');
document.write('<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">');
document.write("<title>Shake It Milkshake's & Smoothies Bar </title>");
document.write('<meta name="description" content="Descrippción">');
document.write('<meta http-equiv="Expires" content="0">');
document.write('<meta http-equiv="Last-Modified" content="0">');
document.write('<meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">');
document.write('<meta http-equiv="Pragma" content="no-cache">');
document.write('<link rel="icon" href="media/favicon.png" type="logo" />');
document.write('<meta name="viewport" content="width=device-width, initial-scale=1">');
document.write('<script>if (typeof module === "object") {window.module = module; module = undefined;}</script>');
document.write('<script src="Recursos/js/jquery-3.2.1.min.js" type="text/javascript"></script>');
document.write('<script>if (window.module) module = window.module;</script>');
document.write('<script src="Recursos/js/popper.min.js" type="text/javascript"></script>');
document.write('<script src="Recursos/Bootstrap/js/bootstrap.min.js" type="text/javascript"></script>');
document.write('<script src="Recursos/Bootstrap/js/bootstrap.bundle.min.js" type="text/javascript"></script>');
document.write('<script src="Recursos/js/md5.js" type="text/javascript"></script>');
document.write('<script src="Recursos/Bootstrap/js/bootstrap.js" type="text/javascript"></script>');
document.write('<script src="Recursos/js/seguridad.js" type="text/javascript"></script>');
document.write('<link href="Recursos/Bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>');
document.write('<link href="Recursos/font-awesome-4.7.0/css/all.min.css" rel="stylesheet" type="text/css"/>');
document.write('<link href="Recursos/css/animate.css" rel="stylesheet" type="text/css"/>');
document.write('<link href="Recursos/css/landing.css" rel="stylesheet" type="text/css"/>');
document.write('<script src="Recursos/bootstrap-notify/bootstrap-notify.min.js" type="text/javascript"></script>');
document.write('<script src="Recursos/bootstrap-notify/bootstrap-notify.js" type="text/javascript"></script>');
document.write('<script src="Recursos/js/funciones.js" type="text/javascript"></script>');
document.write('<script src="Recursos/js/db.js" type="text/javascript"></script>');