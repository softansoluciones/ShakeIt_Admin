$(document).ready(function(){
    Load_Alertas();
    $("#badgeAlert").hide();
})