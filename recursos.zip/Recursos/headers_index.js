/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//document.write('<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />');
document.write('<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">');
document.write('<title>Friki Land</title>');
document.write('<meta name="description" content="Descrippción">');
document.write('<meta http-equiv="Expires" content="0">');
document.write('<meta http-equiv="Last-Modified" content="0">');
document.write('<meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">');
document.write('<meta http-equiv="Pragma" content="no-cache">');
document.write('<link rel="icon" type="logo" />');
document.write('<meta name="viewport" content="width=device-width, initial-scale=1">');
document.write('<script src="js/jquery-3.2.1.min.js" type="text/javascript"></script>');
document.write('<script src="js/popper.min.js" type="text/javascript"></script>');
document.write('<script src="Bootstrap/js/bootstrap.min.js" type="text/javascript"></script>');
document.write('<script src="js/md5.js" type="text/javascript"></script>');
document.write('<script src="Bootstrap/js/bootstrap.js" type="text/javascript"></script>');
document.write('<script src="js/funciones.js" type="text/javascript"></script>');
document.write('<script src="js/seguridad.js" type="text/javascript"></script>');
document.write('<link href=".Bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>');
document.write('<link href="font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>');
document.write('<link href="css/landing_1.css" rel="stylesheet" type="text/css"/>');
document.write('<link href="css/softan.css" rel="stylesheet" type="text/css"/>');
document.write('<link href="css/landing.css" rel="stylesheet" type="text/css"/>');
document.write('<link href="css/botones.css" rel="stylesheet" type="text/css"/>');